#!/usr/bin/env bash
runid=$1
sf=$2
dynamoDBTable=$3
data_bucket_path=$4
ECR_URI=$5

echo aws stepfunctions start-execution \
--state-machine-arn $2 \
--name $1 \
--input "{\"BuildId\": \"$runid\",\"JobName\": \"Job-$runid\",\"Model\": \"Model-$runid\",\"Endpoint\": \"Endpoint-$runid\",\"ecrArn\": \"$ECR_URI:$runid\", \"dataBucketPath\": \"$data_bucket_path\", \"triggerSource\": \"Test\", \"DynamoDBTable\": \"$dynamoDBTable\", \"commitId\": \"NA\"}"

aws stepfunctions start-execution \
--state-machine-arn $2 \
--name $1 \
--input "{\"BuildId\": \"$runid\",\"JobName\": \"Job-$runid\",\"Model\": \"Model-$runid\",\"Endpoint\": \"Endpoint-$runid\",\"ecrArn\": \"$ECR_URI:$runid\", \"dataBucketPath\": \"$data_bucket_path\", \"triggerSource\": \"Test\", \"DynamoDBTable\": \"$dynamoDBTable\", \"commitId\": \"NA\"}"